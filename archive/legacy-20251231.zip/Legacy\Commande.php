<?php

namespace App\Entity\Legacy;

use App\Repository\CommandeRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: CommandeRepository::class)]
#[ORM\Table(name: 'commandes')]
class Commande
{
    public const ETAT_EN_COURS = 'EN_COURS';
    public const ETAT_VALIDEE = 'VALIDEE';
    public const ETAT_PREPAREE = 'PREPAREE';
    public const ETAT_TERMINEE = 'TERMINEE';
    public const ETAT_ANNULEE = 'ANNULEE';

    public const MODE_SUR_PLACE = 'SUR_PLACE';
    public const MODE_EMPORTER = 'EMPORTER';
    public const MODE_LIVRAISON = 'LIVRAISON';

    public const PAIEMENT_WAVE = 'WAVE';
    public const PAIEMENT_OM = 'OM';
    public const PAIEMENT_ESPECES = 'ESPECES';

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(name: 'id_commande')]
    private ?int $id = null;

    #[ORM\Column(name: 'numero_commande', length: 100)]
    private ?string $numeroCommande = null;

    #[ORM\Column(name: 'nom_client', length: 255)]
    private ?string $nomClient = null;

    #[ORM\Column(name: 'telephone_client', length: 20)]
    private ?string $telephoneClient = null;

    #[ORM\Column(name: 'adresse_livraison', type: Types::TEXT, nullable: true)]
    private ?string $adresseLivraison = null;

    #[ORM\Column(name: 'mode_consommation', length: 50)]
    private ?string $modeConsommation = null;

    #[ORM\Column(length: 50)]
    private ?string $etat = self::ETAT_EN_COURS;

    #[ORM\Column(name: 'mode_paiement', length: 50, nullable: true)]
    private ?string $modePaiement = null;

    #[ORM\Column(name: 'paye')]
    private ?bool $paye = false;

    #[ORM\Column(name: 'montant_total', type: Types::DECIMAL, precision: 10, scale: 2)]
    private ?string $montantTotal = null;

    #[ORM\Column(name: 'created_at')]
    private ?\DateTimeImmutable $createdAt = null;

    #[ORM\Column(name: 'updated_at', nullable: true)]
    private ?\DateTimeImmutable $updatedAt = null;

    #[ORM\ManyToOne(inversedBy: 'commandes')]
    #[ORM\JoinColumn(name: 'id_zone', referencedColumnName: 'id_zone', nullable: true)]
    private ?Zone $zone = null;

    #[ORM\OneToMany(targetEntity: CommandeItem::class, mappedBy: 'commande', cascade: ['persist', 'remove'])]
    private Collection $commandeItems;

    public function __construct()
    {
        $this->commandeItems = new ArrayCollection();
        $this->createdAt = new \DateTimeImmutable();
        $this->numeroCommande = 'CMD-' . date('Ymd') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNumeroCommande(): ?string
    {
        return $this->numeroCommande;
    }

    public function setNumeroCommande(string $numeroCommande): static
    {
        $this->numeroCommande = $numeroCommande;
        return $this;
    }

    public function getNomClient(): ?string
    {
        return $this->nomClient;
    }

    public function setNomClient(string $nomClient): static
    {
        $this->nomClient = $nomClient;
        return $this;
    }

    public function getTelephoneClient(): ?string
    {
        return $this->telephoneClient;
    }

    public function setTelephoneClient(string $telephoneClient): static
    {
        $this->telephoneClient = $telephoneClient;
        return $this;
    }

    public function getAdresseLivraison(): ?string
    {
        return $this->adresseLivraison;
    }

    public function setAdresseLivraison(?string $adresseLivraison): static
    {
        $this->adresseLivraison = $adresseLivraison;
        return $this;
    }

    public function getModeConsommation(): ?string
    {
        return $this->modeConsommation;
    }

    public function setModeConsommation(string $modeConsommation): static
    {
        $this->modeConsommation = $modeConsommation;
        return $this;
    }

    public function getEtat(): ?string
    {
        return $this->etat;
    }

    public function setEtat(string $etat): static
    {
        $this->etat = $etat;
        $this->updatedAt = new \DateTimeImmutable();
        return $this;
    }

    public function getModePaiement(): ?string
    {
        return $this->modePaiement;
    }

    public function setModePaiement(?string $modePaiement): static
    {
        $this->modePaiement = $modePaiement;
        return $this;
    }

    public function isPaye(): ?bool
    {
        return $this->paye;
    }

    public function setPaye(bool $paye): static
    {
        $this->paye = $paye;
        return $this;
    }

    public function getMontantTotal(): ?string
    {
        return $this->montantTotal;
    }

    public function setMontantTotal(string $montantTotal): static
    {
        $this->montantTotal = $montantTotal;
        return $this;
    }

    public function getCreatedAt(): ?\DateTimeImmutable
    {
        return $this->createdAt;
    }

    public function setCreatedAt(\DateTimeImmutable $createdAt): static
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    public function getUpdatedAt(): ?\DateTimeImmutable
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt(?\DateTimeImmutable $updatedAt): static
    {
        $this->updatedAt = $updatedAt;
        return $this;
    }

    public function getZone(): ?Zone
    {
        return $this->zone;
    }

    public function setZone(?Zone $zone): static
    {
        $this->zone = $zone;
        return $this;
    }

    public function getCommandeItems(): Collection
    {
        return $this->commandeItems;
    }

    public function addCommandeItem(CommandeItem $commandeItem): static
    {
        if (!$this->commandeItems->contains($commandeItem)) {
            $this->commandeItems->add($commandeItem);
            $commandeItem->setCommande($this);
        }
        return $this;
    }

    public function removeCommandeItem(CommandeItem $commandeItem): static
    {
        if ($this->commandeItems->removeElement($commandeItem)) {
            if ($commandeItem->getCommande() === $this) {
                $commandeItem->setCommande(null);
            }
        }
        return $this;
    }

    public function canBeModified(): bool
    {
        return !in_array($this->etat, [self::ETAT_TERMINEE, self::ETAT_ANNULEE]);
    }

    public function getEtatBadgeClass(): string
    {
        return match($this->etat) {
            self::ETAT_EN_COURS => 'bg-warning',
            self::ETAT_VALIDEE => 'bg-info',
            self::ETAT_PREPAREE => 'bg-primary',
            self::ETAT_TERMINEE => 'bg-success',
            self::ETAT_ANNULEE => 'bg-danger',
            default => 'bg-secondary'
        };
    }
}